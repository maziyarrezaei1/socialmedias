SocialMedia
class SocialMedia(object):
    def __init__(self , Name):
        self.Name =Name
    
    def getName(self):
        return self.Name